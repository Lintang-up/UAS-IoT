<?php
include 'koneksi.php';
$datasensor = mysqli_query($koneksi, "SELECT * FROM `sensor_ultrasonic` ORDER BY id DESC LIMIT 1;");
$data = mysqli_fetch_array($datasensor);
$response = array(
    'detak' => $data['detak'],
    'suhu' => $data['suhu']
);

echo json_encode($response);
?>
